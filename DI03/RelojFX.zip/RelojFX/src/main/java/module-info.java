module com.example.relojfx {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.relojfx to javafx.fxml;
    exports com.example.relojfx;
}
package com.example.relojfx;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class LocalStorage<T> {

  //Archivos bytes
    public void serializarObjeto(T archivo, String direccion) {
        try {
            ObjectOutputStream oos;
            oos = new ObjectOutputStream(new FileOutputStream(direccion));
            oos.writeObject(archivo);
            oos.close();
            System.out.println("INFO: Objecto serializado.");
        } catch (FileNotFoundException ex) {
            System.out.println("+---------------------------------------------");
            System.out.println("|ERROR: Al serializar (Archivo no encontrado).");
            System.out.println("|" + ex.getMessage());
            System.out.println("+---------------------------------------------");
        } catch (IOException ex) {
            System.out.println("+-----------------------------------------------");
            System.out.println("|ERROR: Al serializar (En la salida del objeto).");
            System.out.println("|" + ex.getMessage());
            System.out.println("+-----------------------------------------------");
        }
    }

    public T deSerializarObjeto(String direccion) {
        T archivo = null;
        try {
            ObjectInputStream ois;
            ois = new ObjectInputStream(new FileInputStream(direccion));
            archivo = (T) ois.readObject();
            ois.close();
            System.out.println("INFO: Objecto deserializado.");
            return archivo;
        } catch (FileNotFoundException ex) {
            System.out.println("+-----------------------------------------------");
            System.out.println("|ERROR: Al deserializar (Archivo no encontrado).");
            System.out.println("|" + ex.getMessage());
            System.out.println("+-----------------------------------------------");
        } catch (IOException ex) {
            System.out.println("+--------------------------------------------------");
            System.out.println("|ERROR: Al deserializar (En la entrada del objeto).");
            System.out.println("|" + ex.getMessage());
            System.out.println("+--------------------------------------------------");
        } catch (ClassNotFoundException ex) {
            System.out.println("+---------------------------------------------");
            System.out.println("|ERROR: Al deserializar (Clase no encontrada).");
            System.out.println("|" + ex.getMessage());
            System.out.println("+---------------------------------------------");
        }
        return archivo;
    }

}

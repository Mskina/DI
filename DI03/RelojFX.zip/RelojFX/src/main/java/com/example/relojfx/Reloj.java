package com.example.relojfx;

import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.scene.control.Label;
import javafx.util.Duration;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Reloj implements Serializable {
    private Label labelHora;
    private Timeline timeline;
    private static final long serialVersionUID = 1L;

    public Reloj(){
    }
    public void iniciar(){
        labelHora = new Label();
        labelHora.setStyle("-fx-font-size: 3em; -fx-text-fill: white;");

        timeline = new Timeline(new KeyFrame(Duration.seconds(1), event -> mostrarHora()));
        timeline.setCycleCount(Animation.INDEFINITE);
    }

    private void mostrarHora() {
        LocalDateTime actual = LocalDateTime.now();
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("HH:mm:ss");
        String horaFormateada = actual.format(dtf);

        labelHora.setText(horaFormateada);
    }

    public Timeline getTimeline() {
        return timeline;
    }

    public Label getLabelHora() {
        return labelHora;
    }
}

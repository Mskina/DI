package com.example.relojfx;

import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.IOException;

public class PrincipalFX extends Application {
    private Button btnReanudar;
    private Button btnDetener;

    @Override
    public void start(Stage stage) throws IOException {
        Reloj rlj = serializar();
        btnReanudar= new Button("Reanudar");
        btnDetener = new Button("Detener");

        HBox h1 = new HBox(5, btnReanudar, btnDetener);
        h1.setAlignment(Pos.CENTER);
        h1.setPadding(new Insets(10));

        VBox v1 = new VBox(5, rlj.getLabelHora(), h1);
        v1.setAlignment(Pos.CENTER);
        v1.setPadding(new Insets(10));

        Pane root = new Pane();
        root.setStyle("-fx-background-color: black;");
        root.getChildren().add(v1);

        Scene scene = new Scene(root, 320, 240);
        stage.setTitle("RelojFX");
        stage.setScene(scene);
        stage.show();

        reanudar(rlj.getTimeline());

        EventHandler<ActionEvent> reanudarHandler = new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                reanudar(rlj.getTimeline());
            }
        };
        btnReanudar.setOnAction(reanudarHandler);

        EventHandler<ActionEvent> detenerHandler = new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                detener(rlj.getTimeline());
            }
        };
        btnDetener.setOnAction(detenerHandler);
    }

    private Reloj serializar() {
        Reloj rlj = new Reloj();
        LocalStorage<Reloj> ls = new LocalStorage<>();
        ls.serializarObjeto(rlj,"Reloj.obj");
        rlj = ls.deSerializarObjeto("Reloj.obj");
        rlj.iniciar();
        return rlj;
    }

    public void reanudar(Timeline timeline) {
        timeline.play();
    }
    public void detener(Timeline timeline) {
        timeline.stop();
    }

    public static void main(String[] args) {
        launch();
    }
}
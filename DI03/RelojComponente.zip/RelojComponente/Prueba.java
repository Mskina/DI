

import java.io.FileInputStream;
import java.io.ObjectInputStream;

import javax.swing.JFrame;

public class Prueba {

    public static void main(String[] args) {
        JFrame ventana = new JFrame("Ventana Creada");
        Reloj miReloj;
        try {
            ObjectInputStream flujoEntrada=new ObjectInputStream(new FileInputStream("reloj.obj"));
            String str=(String)flujoEntrada.readObject();
            System.out.println(str);
            miReloj=(Reloj)flujoEntrada.readObject();    
            miReloj.arrancarReloj();
            System.out.println("Características del "+miReloj.toString());
            miReloj.toString();
            ventana.add(miReloj);
            flujoEntrada.close();
        } catch (Exception e) {
            // TODO: handle exception

            System.out.println("Este es mi primer error"+ e.getMessage());
        }
        
		
       // Reloj miReloj = new Reloj();
       
       


        ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);// finaliza el programa cuando se da click en la X
        ventana.setSize(290, 150);// configurando tamaño de la ventana
        ventana.setVisible(true);// configurando visualización de la ventana
        

    }

}
